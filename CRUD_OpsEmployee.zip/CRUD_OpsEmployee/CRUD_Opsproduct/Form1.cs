
using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;
using System.Reflection.Metadata.Ecma335;

namespace CRUD_Ops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=lab;Integrated Security=True;");
        public int EmployeeID;
        private void button1_Click(object sender, EventArgs e)
        {
            ResetFormcontrol();
        }

        private void ResetFormcontrol()
        {

            EmployeeID= 0;
            txtName.Clear();
            txtSalery.Clear();
            txtPost.Clear();
           txtMobile.Clear();
            txtDept.Clear();
            txtName.Focus();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GetStudentsRecord();
        }

        private void GetStudentsRecord()
        {
            //SqlConnection con= new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=lab;Integrated Security=True;");
            SqlCommand cmd = new SqlCommand("Select * from EmployeeTb", con);
            DataTable dt = new DataTable();
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            dt.Load(sdr);
            con.Close();
            EmployeeRecordDataGridView.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (IsValid()) 
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO EmployeeTb VALUES(@name,@Sal,@Post,@Mob,@Dept)",con);
            cmd.CommandType= CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@Sal", txtSalery.Text);
                cmd.Parameters.AddWithValue("@Post", txtPost.Text);
             cmd.Parameters.AddWithValue("@Mob", txtMobile.Text);
                cmd.Parameters.AddWithValue("@Dept", txtDept.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("new Product is Sucessfully saved in database", "saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormcontrol();

            }
        }

        private bool IsValid()
        {
            if (txtName.Text == string.Empty) { MessageBox.Show("Product Data is req", "failed", MessageBoxButtons.OK, MessageBoxIcon.Error); return false; }
            return true;
        }

        private void StudentRecordDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            EmployeeID= Convert.ToInt32(EmployeeRecordDataGridView.SelectedRows[0].Cells[0].Value);
            txtName.Text = EmployeeRecordDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            txtSalery.Text = EmployeeRecordDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            txtPost.Text = EmployeeRecordDataGridView.SelectedRows[0].Cells[3].Value.ToString();
           
            txtMobile.Text = EmployeeRecordDataGridView.SelectedRows[0].Cells[4].Value.ToString();
           txtDept.Text = EmployeeRecordDataGridView.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (EmployeeID > 0)
            {
                SqlCommand cmd = new SqlCommand("UPDATE EmployeeTb SET Name= @name, Salary= @Sal, Post= @Post, Mobile= @Mob,Department=@Dept WHERE Empid= @ID", con);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@Sal", txtSalery.Text);
                cmd.Parameters.AddWithValue("@Post", txtPost.Text);
               cmd.Parameters.AddWithValue("@Mob", txtMobile.Text);
                cmd.Parameters.AddWithValue("@Dept", txtDept.Text);
                cmd.Parameters.AddWithValue("@ID", this.EmployeeID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Product is Sucessfully updated in database", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormcontrol();

            }
            else {
                MessageBox.Show("please select a Product to update his information", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(EmployeeID > 0) 
            {

                SqlCommand cmd = new SqlCommand("DELETE FROM  EmployeeTb  WHERE Empid= @ID", con);
                cmd.CommandType = CommandType.Text;
              //  cmd.Parameters.AddWithValue("@name", txtStudentName.Text);
              //  cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
               // cmd.Parameters.AddWithValue("@RollNumber", txtRollNumber.Text);
              //  cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
              //  cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                cmd.Parameters.AddWithValue("@ID", this.EmployeeID);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Product is Sucessfully DELETED in database", "DELETED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GetStudentsRecord();
                ResetFormcontrol();


            }
            else
            {
                MessageBox.Show("please select a student to DELETE his information", "Select?", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}