import java.util.Arrays;

public class ArrINTR {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4, 5}; // define the first array
        int[] arr2 = {3, 4, 5, 6, 7}; // define the second array

        // sort both arrays
        Arrays.sort(arr1);
        Arrays.sort(arr2);

        int i = 0;
        int j = 0;

        // loop through both arrays to find the common elements
        while (i < arr1.length && j < arr2.length) {
            if (arr1[i] < arr2[j]) {
                i++;
            } else if (arr1[i] > arr2[j]) {
                j++;
            } else {
                System.out.print(arr1[i] + " ");
                i++;
                j++;
            }
        }
    }
}
