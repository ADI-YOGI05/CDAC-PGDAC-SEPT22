public class SecondMinARR {
    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25}; // define an array of numbers

        // Initialize the minimum and second minimum variables
        int minimum = Integer.MAX_VALUE;
        int secondMinimum = Integer.MAX_VALUE;

        // Loop through the array to find the minimum and second minimum elements
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] < minimum) {
                secondMinimum = minimum;
                minimum = numbers[i];
            } else if (numbers[i] < secondMinimum && numbers[i] != minimum) {
                secondMinimum = numbers[i];
            }
        }

        // Print the second minimum number
        System.out.println("The second minimum number in the array is: " + secondMinimum);
    }
}
