public class MiSSINGARRno {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 5, 6, 7, 8, 9, 10}; // define an array of numbers

        int n = numbers.length + 1; // get the expected length of the array
        int expectedSum = n * (n + 1) / 2; // calculate the expected sum of the array
        int actualSum = 0; // initialize the actual sum of the array

        for (int i = 0; i < numbers.length; i++) {
            actualSum += numbers[i]; // add each element of the array to the actual sum
        }

        int missingNumber = expectedSum - actualSum; // calculate the missing number

        System.out.println("The missing number in the array is: " + missingNumber);
    }
}
