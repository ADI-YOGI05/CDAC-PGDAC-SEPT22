public class arrAv {
    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25}; // define an array of numbers
        double sum = 0;

        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i]; // add each element of the array to the sum
        }

        double average = sum / numbers.length; // divide the sum by the number of elements in the array

        System.out.println("The average of the array is: " + average);
    }
}
