import java.util.HashMap;

public class MostFrequentHashCODE {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 2, 2, 5, 6, 5, 2}; // define the array
        int n = arr.length;

        // create a HashTable to store the element counts
        HashMap<Integer, Integer> counts = new HashMap<Integer, Integer>();

        // loop through the array and update the counts
        for (int i = 0; i < n; i++) {
            if (counts.containsKey(arr[i])) {
                counts.put(arr[i], counts.get(arr[i]) + 1);
            } else {
                counts.put(arr[i], 1);
            }
        }

        int maxCount = 0;
        int maxNum = 0;

        // loop through the HashTable to find the most frequent element
        for (Integer key : counts.keySet()) {
            int count = counts.get(key);
            if (count > maxCount) {
                maxCount = count;
                maxNum = key;
            }
        }

        // print the most frequent element
        System.out.println("The most frequent element is: " + maxNum);
    }
}
