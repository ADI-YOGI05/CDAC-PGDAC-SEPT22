public class SecondLargestArr {
    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25}; // define an array of numbers

        // Initialize the largest and second largest variables
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;

        // Loop through the array to find the largest and second largest elements
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] > largest) {
                secondLargest = largest;
                largest = numbers[i];
            } else if (numbers[i] > secondLargest && numbers[i] != largest) {
                secondLargest = numbers[i];
            }
        }

        // Print the second largest number
        System.out.println("The second largest number in the array is: " + secondLargest);
    }
}
