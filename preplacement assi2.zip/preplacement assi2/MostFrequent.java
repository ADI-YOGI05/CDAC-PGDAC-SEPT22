import java.util.Arrays;

public class MostFrequent {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 2, 2, 5, 6, 5, 2}; // define the array
        int n = arr.length;

        // sort the array
        Arrays.sort(arr);

        int currCount = 1;
        int maxCount = 1;
        int currNum = arr[0];
        int maxNum = arr[0];

        // loop through the sorted array
        for (int i = 1; i < n; i++) {
            if (arr[i] == currNum) {
                currCount++;
            } else {
                if (currCount > maxCount) {
                    maxCount = currCount;
                    maxNum = currNum;
                }
                currNum = arr[i];
                currCount = 1;
            }
        }

        // check the last element
        if (currCount > maxCount) {
            maxCount = currCount;
            maxNum = currNum;
        }

        // print the most frequent element
        System.out.println("The most frequent element is: " + maxNum);
    }
}
