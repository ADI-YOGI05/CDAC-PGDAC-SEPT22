import java.util.Arrays;

public class ReverseArr {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5}; // define the array
        int n = arr.length;

        // loop through the array up to its midpoint
        for (int i = 0; i < n / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[n - i - 1];
            arr[n - i - 1] = temp;
        }

        // print the reversed array
        System.out.println(Arrays.toString(arr));
    }
}
