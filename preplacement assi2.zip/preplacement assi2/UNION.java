import java.util.Arrays;

public class UNION {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4, 5}; // define the first sorted array
        int[] arr2 = {3, 4, 5, 6, 7}; // define the second sorted array

        int i = 0;
        int j = 0;

        // loop through both arrays to find the union elements
        while (i < arr1.length && j < arr2.length) {
            if (arr1[i] < arr2[j]) {
                System.out.print(arr1[i] + " ");
                i++;
            } else if (arr1[i] > arr2[j]) {
                System.out.print(arr2[j] + " ");
                j++;
            } else {
                System.out.print(arr1[i] + " ");
                i++;
                j++;
            }
        }

        // print the remaining elements of arr1
        while (i < arr1.length) {
            System.out.print(arr1[i] + " ");
            i++;
        }

        // print the remaining elements of arr2
        while (j < arr2.length) {
            System.out.print(arr2[j] + " ");
            j++;
        }
    }
}
