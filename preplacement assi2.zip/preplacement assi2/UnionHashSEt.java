import java.util.HashSet;

public class UnionHashSEt {
    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4, 5}; // define the first array
        int[] arr2 = {3, 4, 5, 6, 7}; // define the second array

        // create a HashSet to store the union elements
        HashSet<Integer> unionSet = new HashSet<Integer>();

        // add elements from the first array to the HashSet
        for (int num : arr1) {
            unionSet.add(num);
        }

        // add elements from the second array to the HashSet
        for (int num : arr2) {
            unionSet.add(num);
        }

        // print the union elements
        System.out.println(unionSet);
    }
}
