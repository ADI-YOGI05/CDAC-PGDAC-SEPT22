import java.util.Arrays;

public class RotateArr {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5}; // define the array
        int n = arr.length;
        int d = 2; // define the number of rotations

        // rotate the array d times
        for (int i = 0; i < d; i++) {
            int temp = arr[0];
            for (int j = 1; j < n; j++) {
                arr[j - 1] = arr[j];
            }
            arr[n - 1] = temp;
        }

        // print the rotated array
        System.out.println(Arrays.toString(arr));
    }
}
