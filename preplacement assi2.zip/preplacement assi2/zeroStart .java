import java.util.Arrays;

public class zeroStart {
    public static void main(String[] args) {
        int[] arr = {0, 1, 0, 3, 12, 0, 8, 0}; // define the array
        int n = arr.length;

        int count = n - 1; // count of non-zero elements

        // loop through the array and move non-zero elements to the end
        for (int i = n - 1; i >= 0; i--) {
            if (arr[i] != 0) {
                arr[count] = arr[i];
                count--;
            }
        }

        // set remaining elements to 0
        while (count >= 0) {
            arr[count] = 0;
            count--;
        }

        // print the modified array
        System.out.println(Arrays.toString(arr));
    }
}
