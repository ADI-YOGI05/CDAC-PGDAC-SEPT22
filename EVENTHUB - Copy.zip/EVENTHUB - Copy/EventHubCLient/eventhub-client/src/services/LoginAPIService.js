import axios from "axios";

const BASE_URL = "http://localhost:9800/login";

// after installing npm i axios mention below command to make use of axios library

export function saveLogin(login) {
  return axios.post(BASE_URL, login); //post function will return promise so we have to return this
}

export function getLogin() {
  return axios.get(BASE_URL); //returning complete promise from this service layer
  //axios internally working as ajax..but we dont have to write whole fetch data and all in codes
}
