import axios from "axios";

const BASE_URL = "http://localhost:9800/register";

// after installing npm i axios mention below command to make use of axios library

export function saveRegister(register) {
  return axios.post(BASE_URL, register); //post function will return promise so we have to return this
}

export function getRegister() {
  return axios.get(BASE_URL); //returning complete promise from this service layer
  //axios internally working as ajax..but we dont have to write whole fetch data and all in codes
}
