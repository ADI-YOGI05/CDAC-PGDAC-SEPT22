import { useEffect, useState } from "react";
import { Alert, Button, Container, Modal, Table } from "react-bootstrap";
import {
  deleteParticpantFromServer,
  getAllParticipantsFromServer,
} from "../services/ParticipantsAPIService";

export function AllParticipants() {
  const [allParticipants, setAllParticipants] = useState([]);
  //to store id of event on which button is clicked
  const [selectedParticipantId, setSelectedParticipantId] = useState("");
  const [isModalOpened, setIsModalOpened] = useState(false);

  const openModal = () => {
    setIsModalOpened(true);
  };
  const closeModal = () => {
    setIsModalOpened(false);
  };

  async function getAllParticipants() {
    //aios will return promise that has reponse ..need to store it
    const response = await getAllParticipantsFromServer();
    setAllParticipants(response.data);
  }

  //   function to delete data of event

  const deleteParticipant = async () => {
    const response = await deleteParticpantFromServer(selectedParticipantId);
    console.log(response.data); //returned message from server
    closeModal();
    getAllParticipants();
  };

  useEffect(() => {
    getAllParticipants();
  }, []);

  return (
    <>
      <Container className="mt-4 mb-4 text-center">
        <Alert variant="success" className="alertBlock">
          <h2>List Of All Participants</h2>
        </Alert>
      </Container>
      <Container>
        <Table stripped bordered hover variant="dark">
          <thead>
            <tr>
              <th>Event ID</th>
              <th>Category</th>
              <th>Event Name</th>
              <th>Participant ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Contact</th>
              <th>Email</th>
              <th>City</th>
              <th>Tickets</th>
              <th>Price</th>
              <th>Total</th>
              <th>Options</th>
            </tr>
          </thead>
          {/* events will become a JSON object here */}
          <tbody>
            {allParticipants.map((tickets) => {
              return (
                <tr>
                  <td>{tickets.tid}</td>
                  <td>{tickets.tCategory}</td>
                  <td>{tickets.tEveName}</td>
                  <td>{tickets.pid}</td>
                  <td>{tickets.pFname}</td>
                  <td>{tickets.pLname}</td>
                  <td>{tickets.pContact}</td>
                  <td>{tickets.pEmail}</td>
                  <td>{tickets.pLocation}</td>
                  <td>{tickets.pNoTickets}</td>
                  <td>{tickets.pPrice}</td>
                  <td>{tickets.totalCost}</td>
                  <td>
                    <Button
                      variant="danger"
                      className="btn-sm"
                      onClick={() => {
                        setSelectedParticipantId(tickets.pid);
                        openModal();
                      }}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Container>
      <Modal show={isModalOpened} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to Delete Participant with ID :{" "}
          {selectedParticipantId}?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={deleteParticipant}>
            Yes
          </Button>
          <Button variant="danger" onClick={closeModal}>
            No
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
