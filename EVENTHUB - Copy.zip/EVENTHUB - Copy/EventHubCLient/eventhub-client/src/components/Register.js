import { Component } from "react";
import {
  Alert,
  Button,
  Col,
  Container,
  Form,
  Image,
  Modal,
  Row,
} from "react-bootstrap";
import { saveRegister } from "../services/RegisterAPIService";

export class Register extends Component {
  constructor() {
    super();
    this.state = {
      formData: {},
      modalOpeningStatus: false,
      defaultValues: { uemail: "" },
    };

    // this.componentDidMount();
    // 1. send ID from card to book event url
    // 2.use params hook
    //2. read this ID and create component didmount function
    //3. use this ID and Fetch Data from database
    //4. Put the generated response into value field for each form field
    //5.
  }

  openDialog = () => {
    this.setState({ modalOpeningStatus: true });
  };
  closeDialog = () => {
    this.setState({ modalOpeningStatus: false });
  };

  handleChange = (event) => {
    this.setState({
      formData: {
        ...this.state.formData,
        [event.target.name]: event.target.value,
      },
    });
  };

  handleSubmit = async (event) => {
    event.preventDefault(); //prevent reloading of page on submit
    const response = await saveRegister(this.state.formData); //promise returned with response
    console.log(response.data);
    if (response.status == 200) {
      this.setState({
        formData: {
          ufname: "",
          ulname: "",
          uemail: "",
          upass: "",
        },
      });
      this.openDialog();
    }
  };

  render() {
    return (
      <>
        <b>
          <Container className="mt-4 text-center">
            <Alert variant="success" className="alertBlock">
              <h2>Registration</h2>
            </Alert>
          </Container>

          <Container className="mt-4">
            <div className="divSet">
              <div>
                <Form onSubmit={this.handleSubmit}>
                  <Row>
                    <Col lg={7}>
                      <Form.Group className="mb-3">
                        <Form.Label>User First Name</Form.Label>
                        <Form.Control
                          type="text"
                          value={this.state.formData.ufname}
                          placeholder="Enter First Name"
                          name="ufname"
                          onChange={this.handleChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col lg={7}>
                      <Form.Group className="mb-3">
                        <Form.Label>User Last Name</Form.Label>
                        <Form.Control
                          type="text"
                          value={this.state.formData.ulname}
                          placeholder="Enter Last Name"
                          name="ulname"
                          onChange={this.handleChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col lg={7}>
                      <Form.Group className="mb-3">
                        <Form.Label>User Email</Form.Label>
                        <Form.Control
                          type="text"
                          value={this.state.formData.uemail}
                          placeholder="Enter Email"
                          name="uemail"
                          onChange={this.handleChange}
                        />
                      </Form.Group>
                    </Col>
                    <Col lg={7}>
                      <Form.Group className="mb-3">
                        <Form.Label>User Password</Form.Label>
                        <Form.Control
                          type="password"
                          value={this.state.formData.upass}
                          placeholder="Enter Password"
                          name="upass"
                          onChange={this.handleChange}
                        />
                      </Form.Group>
                    </Col>
                  </Row>
                  <Button type="submit" variant="success" className="mb-4">
                    Register New User
                  </Button>
                </Form>
              </div>
              <div>
                <Image
                  src="https://cache.careers360.mobi/media/article_images/2018/05/14/SAT_Registration.jpeg"
                  rounded
                />
              </div>
            </div>
          </Container>
          <Modal show={this.state.modalOpeningStatus} onHide={this.closeDialog}>
            <Modal.Header closeButton>
              <Modal.Title>Status</Modal.Title>
            </Modal.Header>
            <Modal.Body>New User Registered Successfully</Modal.Body>
            <Modal.Footer>
              <Button variant="primary" onClick={this.closeDialog}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>
        </b>
      </>
    );
  }
}
