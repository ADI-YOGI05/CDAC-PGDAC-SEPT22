import { useEffect, useState } from "react";
import { Alert, Col, Container, Row } from "react-bootstrap";
import { getAllEventsFromServer } from "../services/EventsAPIService";
import { ArrangeEvent } from "./SelectEvent";

export function SelectEvent2() {
  const [allEvents, setAllEvents] = useState([]);
  //to store id of event on which button is clicked
  const [selectedEventId, setSelectedEventId] = useState("");

  async function getAllEvents() {
    //axios will return promise that has reponse ..need to store it
    const response = await getAllEventsFromServer();
    setAllEvents(response.data);
  }

  useEffect(() => {
    getAllEvents();
  }, []);

  return (
    <>
      <Container className="mt-4 mb-4 text-center">
        <Alert variant="success" className="alertBlock">
          <h2>List Of All Events</h2>
        </Alert>
      </Container>
      <Container>
        <Row>
          {allEvents.map((event) => {
            return (
              <Col lg={4} className="mb-4">
                <strong>
                  <ArrangeEvent event={event} />
                </strong>
              </Col>
            );
          })}
        </Row>
      </Container>
    </>
  );
}
