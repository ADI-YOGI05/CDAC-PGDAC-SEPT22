import { Component } from "react";
import {
  Alert,
  Button,
  Col,
  Container,
  Form,
  Modal,
  Row,
} from "react-bootstrap";
import { saveEvent } from "../services/EventsAPIService";

export class CreateEventForm extends Component {
  constructor() {
    super();
    this.state = {
      //removing individual key value pair
      // eveid: "",
      // category: "",
      // eveName: "",
      // location: "",
      // eveDesc: "",
      // contact: "",
      // email: "",
      // price: "",

      formData: {},
      modalOpeningStatus: false,
      defaultValues: { eveid: "" },
    };
  }

  openDialog = () => {
    this.setState({ modalOpeningStatus: true });
  };
  closeDialog = () => {
    this.setState({ modalOpeningStatus: false });
  };

  handleChange = (event) => {
    this.setState({
      formData: {
        ...this.state.formData,
        [event.target.name]: event.target.value,
      },
    });
  };

  handleSubmit = async (event) => {
    event.preventDefault(); //prevent reloading of page on submit
    const response = await saveEvent(this.state.formData); //promise returned with response
    console.log(response.data);
    if (response.status == 200) {
      this.setState({
        formData: {
          eveid: "",
          category: "",
          eveName: "",
          location: "",
          eveDesc: "",
          contact: "",
          email: "",
          price: "",
          img: "",
          eveDate: "",
        },
      });
      this.openDialog();
    }
  };

  render() {
    return (
      <>
        <strong>
          <Container className="mt-4 text-center">
            <Alert variant="success" className="alertBlock">
              <h2> Create New Event</h2>
            </Alert>
          </Container>
          <Container className="mt-4">
            <Form onSubmit={this.handleSubmit}>
              <Row>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Id</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.eveid}
                      placeholder="Enter Event id"
                      name="eveid"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Category</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Event Category"
                      name="category"
                      value={this.state.formData.category}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Event Name"
                      name="eveName"
                      value={this.state.formData.eveName}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Location</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Location"
                      name="location"
                      value={this.state.formData.location}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Description</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Description"
                      name="eveDesc"
                      value={this.state.formData.eveDesc}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Contact</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Contact Details"
                      name="contact"
                      value={this.state.formData.contact}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Email</Form.Label>
                    <Form.Control
                      type="email"
                      placeholder="Enter Email"
                      name="email"
                      value={this.state.formData.email}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Entry Cost</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Event Entry Cost"
                      name="price"
                      value={this.state.formData.price}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Input Image URL</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Event URL"
                      name="img"
                      value={this.state.formData.img}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Date</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter Date in dd-mm-yyyy"
                      name="eveDate"
                      value={this.state.formData.eveDate}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Button type="submit" variant="success" className="mb-4">
                Register Event
              </Button>
            </Form>
          </Container>
          <Modal show={this.state.modalOpeningStatus} onHide={this.closeDialog}>
            <Modal.Header closeButton>
              <Modal.Title>Success</Modal.Title>
            </Modal.Header>
            <Modal.Body>Event Created Successfully!</Modal.Body>
            <Modal.Footer>
              <Button variant="primary" onClick={this.closeDialog}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>
        </strong>
      </>
    );
  }
}
