import { useEffect, useState } from "react";
import { Alert, Button, Container, Modal, Table } from "react-bootstrap";
import {
  deleteEventFromServer,
  getAllEventsFromServer,
} from "../services/EventsAPIService";

export function AllEvents() {
  const [allEvents, setAllEvents] = useState([]);
  //to store id of event on which button is clicked
  const [selectedEventId, setSelectedEventId] = useState("");
  const [isModalOpened, setIsModalOpened] = useState(false);

  const openModal = () => {
    setIsModalOpened(true);
  };
  const closeModal = () => {
    setIsModalOpened(false);
  };

  async function getAllEvents() {
    //axios will return promise that has reponse ..need to store it
    const response = await getAllEventsFromServer();
    setAllEvents(response.data);
  }

  //   function to delete data of event

  const deleteEvent = async () => {
    const response = await deleteEventFromServer(selectedEventId);
    console.log(response.data); //returned message from server
    closeModal();
    getAllEvents();
  };

  useEffect(() => {
    getAllEvents();
  }, []);

  return (
    <>
      <Container className="mt-4 mb-4 text-center">
        <Alert variant="success" className="alertBlock">
          <h2>List Of All Events</h2>
        </Alert>
      </Container>
      <Container>
        <Table stripped bordered hover variant="dark">
          <thead>
            <tr>
              <th>Event ID</th>
              <th>Category</th>
              <th>Event Name</th>
              <th>Location</th>
              <th>Contact</th>
              <th>Email</th>
              <th>Ticket Cost</th>
              <th>Options</th>
            </tr>
          </thead>
          {/* events will become a JSON object here */}
          <tbody>
            {allEvents.map((events) => {
              return (
                <tr>
                  <td>{events.eveid}</td>
                  <td>{events.category}</td>
                  <td>{events.eveName}</td>
                  <td>{events.location}</td>
                  <td>{events.contact}</td>
                  <td>{events.email}</td>
                  <td>{events.price}</td>
                  <td>
                    <Button
                      variant="danger"
                      className="btn-sm"
                      onClick={() => {
                        setSelectedEventId(events.eveid);
                        openModal();
                      }}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </Container>
      <Modal show={isModalOpened} onHide={closeModal}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to Delete Event with Event-ID :{" "}
          {selectedEventId}?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={deleteEvent}>
            Yes
          </Button>
          <Button variant="danger" onClick={closeModal}>
            No
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
