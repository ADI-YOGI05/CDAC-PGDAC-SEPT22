import { Component } from "react";
import {
  Alert,
  Button,
  Col,
  Container,
  Form,
  Modal,
  Row,
} from "react-bootstrap";
import { saveParticipant } from "../services/ParticipantsAPIService";

export class BookEvent extends Component {
  constructor() {
    super();
    this.state = {
      formData: {
        tid: localStorage.getItem("eveid"),
        tCategory: localStorage.getItem("category"),
        tEveName: localStorage.getItem("eveName"),
        pPrice: localStorage.getItem("price"),
        pNoTickets: 0,
      },
      modalOpeningStatus: false,
      defaultValues: { pid: "" },
    };

    // this.componentDidMount();
    // 1. send ID from card to book event url
    // 2.use params hook
    //2. read this ID and create component didmount function
    //3. use this ID and Fetch Data from database
    //4. Put the generated response into value field for each form field
    //5.
  }

  openDialog = () => {
    this.setState({ modalOpeningStatus: true });
  };
  closeDialog = () => {
    this.setState({ modalOpeningStatus: false });
  };

  handleChange = (event) => {
    this.setState({
      formData: {
        ...this.state.formData,
        [event.target.name]: event.target.value,
      },
    });
  };

  handleSubmit = async (event) => {
    event.preventDefault(); //prevent reloading of page on submit
    const response = await saveParticipant(this.state.formData); //promise returned with response
    console.log(response.data);
    if (response.status == 200) {
      this.setState({
        formData: {
          tid: "",
          tCategory: "",
          tEveName: "",
          pid: "",
          pFname: "",
          pLname: "",
          pContact: "",
          pEmail: "",
          pLocation: "",
          pNoTickets: "",
          pPrice: "",
          totalCost: "",
        },
      });
      this.openDialog();
      localStorage.clear();
    }
  };

  render() {
    return (
      <>
        <b>
          <Container className="mt-4 text-center">
            <Alert variant="success" className="alertBlock">
              <h2>Booking Ticket</h2>
            </Alert>
          </Container>
          <Container className="mt-4">
            <Form onSubmit={this.handleSubmit}>
              <Row>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Id</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.tid}
                      placeholder="Enter Event Id"
                      name="tid"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Category</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.tCategory}
                      placeholder="Enter Event Category"
                      name="tCategory"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Event Name</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.tEveName}
                      placeholder="Enter Event Name"
                      name="tEveName"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Participant Id</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pid}
                      placeholder="Enter Participant Id"
                      name="pid"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>

                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Participant First Name</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pFname}
                      placeholder="Enter First Name"
                      name="pFname"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Participant Last Name</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pLname}
                      placeholder="Enter Last Name"
                      name="pLname"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Personal Contact</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pContact}
                      placeholder="Enter Contact Details"
                      name="pContact"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Personal Email</Form.Label>
                    <Form.Control
                      type="email"
                      value={this.state.formData.pEmail}
                      placeholder="Enter Email"
                      name="pEmail"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>

                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>City</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pLocation}
                      placeholder="Enter City Name"
                      name="pLocation"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>No. of Tickets</Form.Label>
                    <Form.Control
                      type="number"
                      value={this.state.formData.pNoTickets}
                      placeholder="Enter No. Of Tickets"
                      name="pNoTickets"
                      // defaultValue={0}
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Price Per Ticket</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.pPrice}
                      placeholder="Price Per Ticket"
                      name="pPrice"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
                <Col lg={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Total Amout to be Paid</Form.Label>
                    <Form.Control
                      type="text"
                      value={this.state.formData.totalCost}
                      placeholder="Total Amount"
                      name="totalCost"
                      onChange={this.handleChange}
                    />
                  </Form.Group>
                </Col>
              </Row>
              <Button type="submit" variant="success" className="mb-4">
                Book Ticket
              </Button>
            </Form>
          </Container>
          <Modal show={this.state.modalOpeningStatus} onHide={this.closeDialog}>
            <Modal.Header closeButton>
              <Modal.Title>Success</Modal.Title>
            </Modal.Header>
            <Modal.Body>Ticket Confirmed!</Modal.Body>
            <Modal.Footer>
              <Button variant="primary" onClick={this.closeDialog}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>
        </b>
      </>
    );
  }
}
