import React from "react";
import { MDBCarousel, MDBCarouselItem } from "mdb-react-ui-kit";
import { Container } from "react-bootstrap";

export function Home() {
  return (
    <MDBCarousel showControls fade>
      <MDBCarouselItem
        className="w-100 d-block"
        itemId={1}
        src="https://images-eds-ssl.xboxlive.com/image?url=8Oaj9Ryq1G1_p3lLnXlsaZgGzAie6Mnu24_PawYuDYIoH77pJ.X5Z.MqQPibUVTct9p8sw_RZjBXSqojnjLmaCeZWgKa74f24NUQ6CuoyxU4h1DWMOJkiI0w.LGVCP79m80vmzjacyJ2lPRDc9n1qQMj9fQGKEsCt9QsDzM8KYsmobc77483q_Gx.5JxJ0D_9KUIBPPmKtjUEVzPkt7FquZYFmFc27GFd5fVR5UeC0k-&h=1080&w=1920&format=jpg"
        alt="..."
      />
      <MDBCarouselItem
        className="w-100 d-block"
        itemId={2}
        src="https://wallpaperaccess.com/full/1538639.jpg"
        alt="..."
      />
      <MDBCarouselItem
        className="w-100 d-block"
        itemId={3}
        src="https://www.adobe.com/express/create/photo-collage/media_1e44e705240fd0a4f2c4f446c3a98ae75d9dd4ad5.png?width=750&format=png&optimize=medium"
        alt="..."
      />
    </MDBCarousel>
  );
}
