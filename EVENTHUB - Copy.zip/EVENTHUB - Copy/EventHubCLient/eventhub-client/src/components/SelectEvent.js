import { Button, Card } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

export function ArrangeEvent({ event }) {
  const navigate2link = useNavigate();

  const handleTransfer = () => {
    localStorage.setItem("eveid", event.eveid);
    localStorage.setItem("category", event.category);
    localStorage.setItem("eveName", event.eveName);
    localStorage.setItem("price", event.price);
    navigate2link("/bookEvent");
  };

  return (
    <Card className="cardStyle">
      <Card.Img variant="top" src={event.img} />
      <Card.Body>
        <Card.Title style={{ color: "red" }}>
          {event.eveid} | {event.eveName}
        </Card.Title>
        <hr></hr>
        <Card.Text>
          Category : {event.category} | Location : {event.location}
        </Card.Text>
        <hr></hr>
        <Card.Text>
          Date : {event.eveDate} | Price : {event.price}
        </Card.Text>
        <hr></hr>
        <Card.Text>{event.eveDesc}</Card.Text>
        <hr></hr>
        <Card.Text>
          <Button variant="success" onClick={handleTransfer}>
            Book Now
          </Button>
        </Card.Text>
      </Card.Body>
    </Card>
  );
}

//onClick={() => navigate2link("/bookEvent")}
