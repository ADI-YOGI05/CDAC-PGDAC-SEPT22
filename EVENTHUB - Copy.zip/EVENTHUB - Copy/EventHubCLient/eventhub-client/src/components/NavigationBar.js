import { Component } from "react";
import { Container, Nav, Navbar } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";

export class NavigationBar extends Component {
  render() {
    return (
      <>
        <b>
          <Navbar bg="success" variant="dark" hover="light" className="navTab">
            <Container>
              <Navbar.Brand href="#Home">
                <h1 className="brand">Events-HUB</h1>
              </Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                  <LinkContainer to={"/"}>
                    <Nav.Link>Home</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/createEvent"}>
                    <Nav.Link>Create Event</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/selectEvent2"}>
                    <Nav.Link>View Events</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/bookEvent"}>
                    <Nav.Link>Book Event</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/all-events"}>
                    <Nav.Link>All Events</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/all-participants"}>
                    <Nav.Link>All Participants List</Nav.Link>
                  </LinkContainer>
                  <LinkContainer to={"/register"}>
                    <Nav.Link>Register</Nav.Link>
                  </LinkContainer>
                </Nav>
              </Navbar.Collapse>
            </Container>
          </Navbar>
        </b>
      </>
    );
  }
}
