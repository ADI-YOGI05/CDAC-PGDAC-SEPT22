import React from "react";
import {
  MDBFooter,
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBIcon,
} from "mdb-react-ui-kit";

export function Footer() {
  return (
    <MDBFooter bgColor="dark" className=" text-center text-lg-start text-muted">
      <section
        className="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
        style={{ backgroundColor: "rgba(72 122 180 / .2)" }}
      >
        <div className="me-5 d-none d-lg-block">
          <span>
            <h4>About US:</h4>
          </span>
        </div>

        <div></div>

        <div>
          <p>
            <b>
              Events-HUB is HTML CSS Based website which is design to navigate
              and browse through events in cities from all fields and book
              tickets. The aim of project is to Help event managers organize
              great events by providing them an awesome online, do it yourself,
              event ticketing and registration platform to sell event tickets
              online without any hassle.
            </b>
          </p>

          {/* <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="facebook-f" />
          </a>
          <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="twitter" />
          </a>
          <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="google" />
          </a>
          <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="instagram" />
          </a>
          <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="linkedin" />
          </a>
          <a href="" className="me-4 text-reset">
            <MDBIcon fab icon="github" />
          </a> */}
        </div>
      </section>

      <section className="">
        <MDBContainer className="text-center text-md-start mt-5">
          <MDBRow className="mt-3">
            <MDBCol md="3" lg="4" xl="3" className="mx-auto mb-4">
              <h4 className="text-uppercase fw-bold mb-4">
                <MDBIcon icon="gem" className="me-3" />
                Project Details:
              </h4>
              <p>
                Designed and Developed by:<br></br>
                Aditya: 220940320005-KH<br></br>
                Pratik Pawar: 220940320084-KH<br></br>
                Vaibhav Barhate: 220940320129-KH<br></br>
              </p>
              <p>Technology Used: CSS,HTML,BOOTSTRAP,REACT-JS,MYSQL</p>
            </MDBCol>

            <MDBCol md="2" lg="2" xl="2" className="mx-auto mb-4">
              <h4 className="text-uppercase fw-bold mb-4">References</h4>
              <p>
                <a
                  href="https://www.w3schools.com/html/"
                  className="text-reset"
                >
                  HTML
                </a>
              </p>
              <p>
                <a href="https://www.w3schools.com/css/" className="text-reset">
                  CSS
                </a>
              </p>
              <p>
                <a
                  href="https://www.w3schools.com/bootstrap5/"
                  className="text-reset"
                >
                  BOOTSTRAP
                </a>
              </p>
              <p>
                <a
                  href="https://www.w3schools.com/react/default.asp"
                  className="text-reset"
                >
                  REACT-JS
                </a>
              </p>
              <p>
                <a
                  href="https://www.w3schools.com/sql/sql_where.asp"
                  className="text-reset"
                >
                  MYSQL
                </a>
              </p>
            </MDBCol>

            <MDBCol md="3" lg="2" xl="2" className="mx-auto mb-4">
              <h4 className="text-uppercase fw-bold mb-4">Useful links</h4>
              <p>
                <a
                  href="https://www.townscript.com/in/online"
                  className="text-reset"
                >
                  TownScript
                </a>
              </p>
              <p>
                <a
                  href="https://www.eventbrite.com/d/india/events/"
                  className="text-reset"
                >
                  EventBrite
                </a>
              </p>
              <p>
                <a href="https://www.strava.com/" className="text-reset">
                  Strava
                </a>
              </p>

              <p>
                <a
                  href="https://allevents.in/location.php?country=india"
                  className="text-reset"
                >
                  AllEVENTS.IN
                </a>
              </p>
              <p>
                <a href="https://www.indiaeve.com/" className="text-reset">
                  IndiaEve
                </a>
              </p>
            </MDBCol>

            <MDBCol md="4" lg="3" xl="3" className="mx-auto mb-md-0 mb-4">
              <h4 className="text-uppercase fw-bold mb-4">Contact</h4>
              <p>
                <MDBIcon icon="home" className="me-2" />
                CDAC, Kharghar, Mumbai-400614
              </p>
              <p>
                <MDBIcon icon="envelope" className="me-3" />
                dackharghar@cdac.in
              </p>
              <p>
                <MDBIcon icon="phone" className="me-3" /> 9425135487
              </p>
              <p>
                <MDBIcon icon="print" className="me-3" /> 02114-277997
              </p>
            </MDBCol>
          </MDBRow>
        </MDBContainer>
      </section>

      <div
        className="text-center p-4"
        style={{ backgroundColor: "rgba(72 122 180 / .2)" }}
      >
        <strong>
          © 2022 Copyright:
          <a className="text-reset fw-bold" href="http://localhost:3000/">
            WPT-Project-Sept Batch-2022
          </a>
        </strong>
      </div>
    </MDBFooter>
  );
}
