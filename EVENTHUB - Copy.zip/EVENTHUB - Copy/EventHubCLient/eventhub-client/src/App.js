import { BrowserRouter, Route, Routes } from "react-router-dom";
import { NavigationBar } from "./components/NavigationBar";
import { Home } from "./components/Home";
import { CreateEventForm } from "./components/CreateEventForm";
import { AllEvents } from "./components/AllEvents";
import { BookEvent } from "./components/BookEvent";
import { AllParticipants } from "./components/AllParticipants";
import { SelectEvent2 } from "./components/SelectEvent2";
import { Footer } from "./components/Footer";
import "bootstrap/dist/css/bootstrap.min.css";
import { Register } from "./components/Register";

function App() {
  return (
    <>
      <BrowserRouter>
        <NavigationBar></NavigationBar>
        <Routes>
          <Route path="/" element={<Home></Home>}></Route>
          <Route
            path="/createEvent"
            element={<CreateEventForm></CreateEventForm>}
          ></Route>
          {/* <Route path="/selectEvent" element={<BookEvent></BookEvent>}></Route> */}
          <Route path="/bookEvent" element={<BookEvent></BookEvent>}></Route>
          <Route path="/all-events" element={<AllEvents></AllEvents>}></Route>
          <Route path="/selectEvent2" element={<SelectEvent2 />}></Route>
          <Route
            path="/all-participants"
            element={<AllParticipants></AllParticipants>}
          ></Route>
          <Route path="/register" element={<Register></Register>}></Route>
        </Routes>
        <Footer></Footer>
      </BrowserRouter>
    </>
  );
}

export default App;
