import express from "express";
import { createConnection } from "mysql";
import cors from "cors";

const app = express();
//middleware to use when CORS error occurs
app.use(cors());
//middleware to read json request body
app.use(express.json());

//nodejs mysql w3school
//we get connection object in return..using which we can send sql queries to database
const conn = createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  //add this seperately
  database: "dbeventhub",
});

//to check your connection is successfull or not use below
conn.connect((error) => {
  if (error) {
    console.log(error);
  } else {
    console.log("Database Connected Successfully !");
  }
});

app.post("/createEvent", (request, response) => {
  var insertQry = `INSERT INTO events VALUES('${request.body.eveid}',
                                             '${request.body.category}',
                                             '${request.body.eveName}',
                                             '${request.body.location}',
                                             '${request.body.eveDesc}',
                                             '${request.body.contact}',
                                             '${request.body.email}',
                                             '${request.body.price}',
                                             '${request.body.img}',
                                             '${request.body.eveDate}')`;

  //send insert query to databse for creating connection
  conn.query(insertQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in inserting event" });
    } else {
      response.status(200).send({ message: "Event Registered Succesfully" });
    }
  });
});

app.get("/createEvent", (request, response) => {
  var selectQry = "SELECT * from events";
  conn.query(selectQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in fetching event" });
    } else {
      response.status(200).send(result);
      //result will assign all objects in form of json object
      //its query function which vconverts all raw data into array of json object
    }
  });
});

app.delete("/createEvent/:eveid", (request, response) => {
  var deleteQry =
    "DELETE FROM events where eveid=" + `"${request.params.eveid}"`;
  console.log(deleteQry);
  conn.query(deleteQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in Deleting Event" });
    } else {
      response.status(200).send({ message: "Successfully Deleted Event" });
      //result will assign all object s in form of json object
      //its query function which vconverts all raw data into array of json object
    }
  });
});

// //to get any particular event data
// app.get("/eventhub/:eveid", (request, response) => {
//   var selectQry = "SELECT * from events";
//   conn.query(selectQry, (error, result) => {
//     if (error) {
//       response.status(500).send({ message: "Error in fetching event" });
//     } else {
//       response.status(200).send(result);
//       //result will assign all object s in form of json object
//       //its query function which vconverts all raw data into array of json object
//     }
//   });
// });

//---------------------------------------------------------------------------------------------
//-------for tickets tables

app.post("/bookEvent", (request, response) => {
  var insertQry = `INSERT INTO tickets VALUES('${request.body.tid}',
                                             '${request.body.tCategory}',
                                             '${request.body.tEveName}',
                                             '${request.body.pid}',
                                             '${request.body.pFname}',
                                             '${request.body.pLname}',
                                             '${request.body.pContact}',
                                             '${request.body.pEmail}',
                                             '${request.body.pLocation}',
                                             '${request.body.pNoTickets}',
                                             '${request.body.pPrice}',
                                             '${request.body.totalCost}')`;

  //send insert query to databse for creating connection
  conn.query(insertQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in inserting Info" });
    } else {
      response
        .status(200)
        .send({ message: "Paticipant Registered Succesfully" });
    }
  });
});

app.get("/bookEvent", (request, response) => {
  var selectQry = "SELECT * from tickets";
  conn.query(selectQry, (error, result) => {
    if (error) {
      response
        .status(500)
        .send({ message: "Error in fetching Participants Details" });
    } else {
      response.status(200).send(result);
      //result will assign all object s in form of json object
      //its query function which vconverts all raw data into array of json object
    }
  });
});

app.delete("/bookEvent/:pid", (request, response) => {
  var deleteQry = "DELETE FROM tickets where pid=" + `"${request.params.pid}"`;
  conn.query(deleteQry, (error, result) => {
    if (error) {
      response
        .status(500)
        .send({ message: "Error in Deleting Participant Detials" });
    } else {
      response
        .status(200)
        .send({ message: "Successfully Deleted Participants Data" });
      //result will assign all object s in form of json object
      //its query function which vconverts all raw data into array of json object
    }
  });
});

//---------------------------------------------------------------------------------
//table - users

app.post("/register", (request, response) => {
  var insertQry = `INSERT INTO users VALUES('${request.body.ufname}',
                                             '${request.body.ulname}',
                                             '${request.body.uemail}',
                                             '${request.body.upass}')`;

  //send insert query to databse for creating connection
  conn.query(insertQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "Error in creating User" });
    } else {
      response.status(200).send({ message: "User Registered Succesfully" });
    }
  });
});

app.get("/register", (request, response) => {
  var selectQry = "SELECT * from users";
  conn.query(selectQry, (error, result) => {
    if (error) {
      response.status(500).send({ message: "No User Found" });
    } else {
      response.status(200).send(result);
      //result will assign all object s in form of json object
      //its query function which vconverts all raw data into array of json object
    }
  });
});

app.listen(9800, () => {
  console.log("Listening on port no 9800");
});
